from flask import Flask, render_template, request
import json
from random import randint

app = Flask(__name__)


@app.route('/member')
def member():
    with open('templates/info.json', encoding='utf8') as info_file:
        f = info_file.read()
        data = json.loads(f)

        card = data[randint(0, 3)]

    return render_template('personal_card.html',
                           title="Личная карточка",
                           name=card['name'],
                           profession=', '.join([x for x in card['profession']]),
                           picture=card['picture'])


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
