from flask import Flask, url_for, \
    render_template, request

app = Flask(__name__)


@app.route('/login', methods=['POST', 'GET'])
def root():
    if request.method == 'GET':
        return render_template('d_guard.html', title="Аварийный доступ")
    elif request.method == 'POST':
        print(request.form['name-a'])
        print(request.form['password-a'])
        print(request.form['name-k'])
        print(request.form['password-k'])
        return "Форма отправлена"


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
