from flask import Flask, render_template, request
import os
from PIL import Image
import uuid

app = Flask(__name__)


@app.route('/gallery', methods=['POST', 'GET'])
def gallery():
    if request.method == 'GET':
        image_list = os.listdir('C:/Users/User/PycharmProjects/flask_/static/img')
        return render_template('gallery_w_d.html',
                               title="Галерея с загрузкой",
                               image_list=image_list)
    elif request.method == 'POST':
        f = request.files['file']
        image = Image.open(f)
        image = image.resize((700, 700), Image.LANCZOS)
        safeId = uuid.uuid4()
        image.save(f"{os.getcwd()}/static/img/{safeId}.png")

        return "Форма отправлена"


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
