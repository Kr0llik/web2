from flask import Flask, url_for, \
    render_template, request

app = Flask(__name__)


@app.route('/distribution')
def root():
    return render_template('cabin.html', title="По каютам!")


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
