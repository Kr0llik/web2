from flask import Flask, url_for, render_template

app = Flask(__name__)


@app.route('/index')
def root():
    return "Миссия Колонизация Марса"


@app.route('/list_prof/<lst>')
def promotion(lst):
    profession = ['инженер-исследватель', 'пилот', 'астроном',
                  'врач', 'экзобиолог', 'климатолог',
                  'астрогеолог', 'гляциолог', 'метеоролог',
                  'оператор марсохода', 'киберинженер', 'пилот дронов']
    return render_template('list_prof.html', profession=profession, lst=lst)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
